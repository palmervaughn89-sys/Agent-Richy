"""
Agent Richy — Bootstrap Script
================================
This script creates the Agent Richy AI assistant using the OpenAI Assistants API.
It uploads all knowledge base files, sets the system prompt, and configures tools.

USAGE:
    1. Set your OPENAI_API_KEY in .env
    2. Run: python create_agent.py
    3. It will create the assistant + upload all knowledge files
    4. Save the assistant_id — you'll need it for the API server

REQUIREMENTS:
    pip install openai python-dotenv
"""

import os
import glob
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ── Configuration ──────────────────────────────────────
ASSISTANT_NAME = "Agent Richy"
MODEL = "gpt-4o"  # or "gpt-4o-mini" for cheaper testing
KNOWLEDGE_BASE_DIR = "./knowledge_base"
SYSTEM_PROMPT_FILE = "./prompts/system_prompt.md"
OUTPUT_FILE = "./configs/assistant_config.json"


def load_system_prompt() -> str:
    """Load the system prompt from file."""
    with open(SYSTEM_PROMPT_FILE, "r") as f:
        return f.read()


def upload_knowledge_files() -> list[str]:
    """Upload all knowledge base files to OpenAI and return file IDs."""
    file_ids = []
    knowledge_files = sorted(glob.glob(f"{KNOWLEDGE_BASE_DIR}/*.md"))

    if not knowledge_files:
        print("⚠️  No knowledge base files found in", KNOWLEDGE_BASE_DIR)
        return file_ids

    print(f"\n📚 Uploading {len(knowledge_files)} knowledge base files...\n")

    for filepath in knowledge_files:
        filename = Path(filepath).name
        print(f"  📄 Uploading: {filename}")

        with open(filepath, "rb") as f:
            file = client.files.create(file=f, purpose="assistants")
            file_ids.append(file.id)
            print(f"     ✅ Uploaded: {file.id}")

    print(f"\n✅ All {len(file_ids)} files uploaded successfully!\n")
    return file_ids


def create_vector_store(file_ids: list[str]) -> str:
    """Create a vector store with the uploaded files for file_search."""
    print("🗄️  Creating vector store...")

    vector_store = client.vector_stores.create(
        name="Agent Richy Knowledge Base",
        file_ids=file_ids,
    )

    print(f"  ✅ Vector store created: {vector_store.id}\n")
    return vector_store.id


def create_assistant(system_prompt: str, vector_store_id: str) -> str:
    """Create the Agent Richy assistant with file_search and code_interpreter."""
    print("🤖 Creating Agent Richy assistant...\n")

    assistant = client.beta.assistants.create(
        name=ASSISTANT_NAME,
        instructions=system_prompt,
        model=MODEL,
        tools=[
            {"type": "file_search"},       # RAG over knowledge base
            {"type": "code_interpreter"},   # For calculations, charts, data analysis
        ],
        tool_resources={
            "file_search": {
                "vector_store_ids": [vector_store_id]
            }
        },
        metadata={
            "app": "agent-richy",
            "version": "2.0",
            "description": "AI Financial Coach with coupon scalping"
        }
    )

    print(f"  ✅ Assistant created!")
    print(f"  📋 Assistant ID: {assistant.id}")
    print(f"  📋 Name: {assistant.name}")
    print(f"  📋 Model: {assistant.model}")
    print(f"  📋 Tools: {[t.type for t in assistant.tools]}")

    return assistant.id


def save_config(assistant_id: str, vector_store_id: str, file_ids: list[str]):
    """Save the configuration for use by the API server."""
    import json

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    config = {
        "assistant_id": assistant_id,
        "vector_store_id": vector_store_id,
        "file_ids": file_ids,
        "model": MODEL,
        "assistant_name": ASSISTANT_NAME,
    }

    with open(OUTPUT_FILE, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n💾 Config saved to {OUTPUT_FILE}")


def main():
    print("=" * 60)
    print("🚀 Agent Richy — Bootstrap Script")
    print("=" * 60)

    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("\n❌ ERROR: OPENAI_API_KEY not found in environment or .env file")
        print("   Create a .env file with: OPENAI_API_KEY=sk-your-key-here")
        return

    # Step 1: Load system prompt
    print("\n📝 Loading system prompt...")
    system_prompt = load_system_prompt()
    print(f"   ✅ System prompt loaded ({len(system_prompt)} characters)")

    # Step 2: Upload knowledge base files
    file_ids = upload_knowledge_files()

    if not file_ids:
        print("❌ No files uploaded. Check your knowledge_base/ directory.")
        return

    # Step 3: Create vector store
    vector_store_id = create_vector_store(file_ids)

    # Step 4: Create assistant
    assistant_id = create_assistant(system_prompt, vector_store_id)

    # Step 5: Save config
    save_config(assistant_id, vector_store_id, file_ids)

    print("\n" + "=" * 60)
    print("🎉 Agent Richy is LIVE!")
    print("=" * 60)
    print(f"\nAssistant ID: {assistant_id}")
    print(f"Vector Store: {vector_store_id}")
    print(f"Files: {len(file_ids)} knowledge docs uploaded")
    print(f"\nNext steps:")
    print(f"  1. Run the API server: python api_server.py")
    print(f"  2. Or test directly: python test_chat.py")
    print(f"  3. Or use the assistant_id in your app")


if __name__ == "__main__":
    main()
