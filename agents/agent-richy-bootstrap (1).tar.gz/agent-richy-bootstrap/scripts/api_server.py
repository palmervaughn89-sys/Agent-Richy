"""
Agent Richy — API Server
=========================
FastAPI server that exposes Agent Richy as an API.
Handles chat, coupon lookups, and structured responses.

USAGE:
    1. First run create_agent.py to set up the assistant
    2. Then: uvicorn api_server:app --reload --port 8000

REQUIREMENTS:
    pip install fastapi uvicorn openai python-dotenv httpx pydantic
"""

import os
import json
import time
import httpx
from typing import Optional
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from openai import OpenAI

load_dotenv()

# ── Initialize ─────────────────────────────────────────
app = FastAPI(title="Agent Richy API", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Load assistant config
CONFIG_FILE = "./configs/assistant_config.json"
with open(CONFIG_FILE, "r") as f:
    config = json.load(f)

ASSISTANT_ID = config["assistant_id"]

# Coupon API config (sign up at couponapi.org or linkmydeals.com)
COUPON_API_KEY = os.getenv("COUPON_API_KEY", "")
COUPON_API_URL = os.getenv("COUPON_API_URL", "https://api.couponapi.org/v1")


# ── Models ─────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    thread_id: Optional[str] = None
    user_id: Optional[str] = None


class ChatResponse(BaseModel):
    message: str
    thread_id: str
    agent: str
    sources: list[str] = []


class CouponRequest(BaseModel):
    stores: list[str]
    categories: list[str] = []
    zip_code: Optional[str] = None


class CouponResult(BaseModel):
    store: str
    title: str
    code: Optional[str] = None
    discount: str
    url: str
    expiry: Optional[str] = None


class ShoppingProfile(BaseModel):
    user_id: str
    grocery_stores: list[str] = []
    online_retailers: list[str] = []
    restaurants: list[str] = []
    gas_stations: list[str] = []
    categories: list[str] = []
    zip_code: str = ""


# ── In-memory stores (replace with DB in production) ───
threads: dict[str, str] = {}  # user_id -> thread_id
shopping_profiles: dict[str, ShoppingProfile] = {}
savings_tracker: dict[str, float] = {}  # user_id -> total savings


# ── Chat Endpoint ──────────────────────────────────────
@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """Main chat endpoint. Sends message to Agent Richy and returns response."""

    # Get or create thread
    thread_id = req.thread_id
    if not thread_id:
        if req.user_id and req.user_id in threads:
            thread_id = threads[req.user_id]
        else:
            thread = client.beta.threads.create()
            thread_id = thread.id
            if req.user_id:
                threads[req.user_id] = thread_id

    # Add user message to thread
    client.beta.threads.messages.create(
        thread_id=thread_id,
        role="user",
        content=req.message,
    )

    # Run the assistant
    run = client.beta.threads.runs.create(
        thread_id=thread_id,
        assistant_id=ASSISTANT_ID,
    )

    # Poll for completion
    while run.status in ("queued", "in_progress"):
        time.sleep(0.5)
        run = client.beta.threads.runs.retrieve(
            thread_id=thread_id,
            run_id=run.id,
        )

    if run.status == "failed":
        raise HTTPException(status_code=500, detail=f"Assistant run failed: {run.last_error}")

    # Get the assistant's response
    messages = client.beta.threads.messages.list(thread_id=thread_id, limit=1)
    assistant_message = messages.data[0]

    # Extract text content
    response_text = ""
    sources = []
    for block in assistant_message.content:
        if block.type == "text":
            response_text += block.text.value
            # Extract citations/annotations if present
            if hasattr(block.text, "annotations"):
                for annotation in block.text.annotations:
                    if hasattr(annotation, "file_citation"):
                        sources.append(annotation.file_citation.file_id)

    # Detect which agent responded based on content
    agent = detect_agent(req.message, response_text)

    return ChatResponse(
        message=response_text,
        thread_id=thread_id,
        agent=agent,
        sources=sources,
    )


# ── Streaming Chat Endpoint ────────────────────────────
@app.post("/api/chat/stream")
async def chat_stream(req: ChatRequest):
    """Streaming chat endpoint using SSE."""

    thread_id = req.thread_id
    if not thread_id:
        thread = client.beta.threads.create()
        thread_id = thread.id

    client.beta.threads.messages.create(
        thread_id=thread_id,
        role="user",
        content=req.message,
    )

    def generate():
        with client.beta.threads.runs.stream(
            thread_id=thread_id,
            assistant_id=ASSISTANT_ID,
        ) as stream:
            for text in stream.text_deltas:
                yield f"data: {json.dumps({'text': text})}\n\n"
        yield f"data: {json.dumps({'done': True, 'thread_id': thread_id})}\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


# ── Coupon Endpoints ───────────────────────────────────
@app.post("/api/coupons/search")
async def search_coupons(req: CouponRequest):
    """Search for coupons based on user's stores and preferences."""

    if not COUPON_API_KEY:
        # Fallback: return mock data for development
        return {
            "coupons": get_mock_coupons(req.stores),
            "total_potential_savings": "$24.50",
            "source": "mock_data"
        }

    # Real API call to coupon provider
    async with httpx.AsyncClient() as http:
        all_coupons = []

        for store in req.stores:
            try:
                response = await http.get(
                    f"{COUPON_API_URL}/coupons",
                    params={
                        "store": store,
                        "api_key": COUPON_API_KEY,
                        "format": "json",
                    },
                    timeout=10.0,
                )

                if response.status_code == 200:
                    data = response.json()
                    coupons = data.get("coupons", data.get("offers", []))

                    for coupon in coupons[:5]:  # Limit per store
                        all_coupons.append(CouponResult(
                            store=store,
                            title=coupon.get("title", coupon.get("offer", "")),
                            code=coupon.get("code", coupon.get("coupon_code")),
                            discount=coupon.get("discount", coupon.get("offer_value", "Deal")),
                            url=coupon.get("url", coupon.get("affiliate_link", "")),
                            expiry=coupon.get("expiry", coupon.get("end_date")),
                        ))
            except Exception as e:
                print(f"Error fetching coupons for {store}: {e}")
                continue

        total_savings = estimate_savings(all_coupons)

        return {
            "coupons": [c.model_dump() for c in all_coupons],
            "total_potential_savings": f"${total_savings:.2f}",
            "count": len(all_coupons),
        }


@app.post("/api/coupons/daily")
async def daily_coupons(user_id: str):
    """Get personalized daily coupons based on user's shopping profile."""

    profile = shopping_profiles.get(user_id)
    if not profile:
        return {"error": "No shopping profile found. Set one up first.", "coupons": []}

    all_stores = (
        profile.grocery_stores +
        profile.online_retailers +
        profile.restaurants +
        profile.gas_stations
    )

    req = CouponRequest(
        stores=all_stores,
        categories=profile.categories,
        zip_code=profile.zip_code,
    )

    return await search_coupons(req)


# ── Shopping Profile Endpoints ─────────────────────────
@app.post("/api/profile/shopping")
async def save_shopping_profile(profile: ShoppingProfile):
    """Save user's shopping preferences for personalized coupons."""
    shopping_profiles[profile.user_id] = profile
    return {"status": "saved", "stores_tracked": len(
        profile.grocery_stores + profile.online_retailers +
        profile.restaurants + profile.gas_stations
    )}


@app.get("/api/profile/shopping/{user_id}")
async def get_shopping_profile(user_id: str):
    """Get user's shopping profile."""
    profile = shopping_profiles.get(user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile


# ── Savings Tracker ────────────────────────────────────
@app.get("/api/savings/{user_id}")
async def get_savings(user_id: str):
    """Get user's total savings from coupons."""
    total = savings_tracker.get(user_id, 0.0)
    return {
        "user_id": user_id,
        "total_savings": f"${total:.2f}",
        "message": f"Richy has saved you ${total:.2f} so far! 🎯"
    }


@app.post("/api/savings/{user_id}/add")
async def add_savings(user_id: str, amount: float):
    """Track when a user redeems a coupon."""
    savings_tracker[user_id] = savings_tracker.get(user_id, 0.0) + amount
    return {"new_total": f"${savings_tracker[user_id]:.2f}"}


# ── Keystroke Reaction Endpoint ────────────────────────
@app.post("/api/keystroke")
async def keystroke_reaction(partial_text: str):
    """Lightweight endpoint for avatar reactions while user types."""

    TRIGGERS = {
        "empathetic": ["debt", "owe", "behind", "late payment", "collections", "scared", "worried", "stressed"],
        "confused": ["crypto", "bitcoin", "moon", "yolo", "meme coin", "nft"],
        "excited": ["save", "saving", "invest", "compound", "grow", "retire", "million", "freedom"],
        "thinking": ["budget", "plan", "track", "spending", "how much"],
        "laughing": ["lol", "haha", "funny"],
        "serious": ["tax", "taxes", "irs", "audit"],
        "celebrating": ["kid", "child", "teach", "emergency fund", "paid off"],
    }

    lower = partial_text.lower()
    best_expression = "watching"
    best_priority = 0

    for expression, keywords in TRIGGERS.items():
        for kw in keywords:
            if kw in lower:
                priority = len(kw)  # Longer match = higher priority
                if priority > best_priority:
                    best_expression = expression
                    best_priority = priority

    QUIPS = {
        "empathetic": "We'll figure this out together 💪",
        "confused": "Oh boy, here we go... 👀",
        "excited": "Now you're talking! 🎯",
        "thinking": "Let me think about this... 🧠",
        "laughing": "Haha! 😄",
        "serious": "Nobody's favorite topic... 😅",
        "celebrating": "Love to see it! 🎉",
        "watching": "I'm reading along... 👀",
    }

    return {
        "expression": best_expression,
        "quip": QUIPS.get(best_expression, ""),
    }


# ── Health Check ───────────────────────────────────────
@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "assistant_id": ASSISTANT_ID,
        "model": config["model"],
    }


# ── Helper Functions ───────────────────────────────────
def detect_agent(question: str, response: str) -> str:
    """Detect which specialist agent the response aligns with."""
    q = question.lower()
    if any(w in q for w in ["budget", "spend", "expense", "subscription", "bill"]):
        return "budget_bot"
    if any(w in q for w in ["invest", "stock", "401k", "ira", "portfolio", "market"]):
        return "invest_intel"
    if any(w in q for w in ["debt", "loan", "credit card", "owe", "payoff", "collections"]):
        return "debt_destroyer"
    if any(w in q for w in ["save", "emergency", "savings", "hysa", "sinking fund"]):
        return "savings_sage"
    if any(w in q for w in ["kid", "child", "teach", "son", "daughter", "allowance"]):
        return "kid_coach"
    return "coach_richy"


def estimate_savings(coupons: list[CouponResult]) -> float:
    """Rough estimate of potential savings from a list of coupons."""
    total = 0.0
    for c in coupons:
        discount = c.discount.lower()
        try:
            if "%" in discount:
                pct = float(discount.replace("%", "").replace("off", "").strip())
                total += pct * 0.5  # Rough estimate: avg $50 purchase * pct
            elif "$" in discount:
                total += float(discount.replace("$", "").replace("off", "").strip())
            else:
                total += 2.50  # Default estimate for unquantified deals
        except (ValueError, AttributeError):
            total += 2.50
    return total


def get_mock_coupons(stores: list[str]) -> list[dict]:
    """Return mock coupons for development/testing."""
    mock_db = {
        "walmart": [
            {"store": "Walmart", "title": "$5 off $50 grocery order", "code": "SAVE5NOW", "discount": "$5 off", "url": "https://walmart.com", "expiry": "2026-03-15"},
            {"store": "Walmart", "title": "15% off home essentials", "code": None, "discount": "15% off", "url": "https://walmart.com/deals", "expiry": "2026-03-10"},
        ],
        "target": [
            {"store": "Target", "title": "Target Circle: 20% off one item", "code": "CIRCLE20", "discount": "20% off", "url": "https://target.com", "expiry": "2026-03-20"},
        ],
        "amazon": [
            {"store": "Amazon", "title": "$10 off $50 with Prime", "code": "PRIME10", "discount": "$10 off", "url": "https://amazon.com", "expiry": "2026-03-12"},
            {"store": "Amazon", "title": "Subscribe & Save extra 15%", "code": None, "discount": "15% off", "url": "https://amazon.com/subscribe-save", "expiry": None},
        ],
        "kroger": [
            {"store": "Kroger", "title": "Free item Friday - check app", "code": None, "discount": "Free item", "url": "https://kroger.com", "expiry": "2026-03-07"},
        ],
        "chipotle": [
            {"store": "Chipotle", "title": "BOGO free entree", "code": "BOGO2026", "discount": "Buy 1 Get 1", "url": "https://chipotle.com", "expiry": "2026-03-08"},
        ],
        "starbucks": [
            {"store": "Starbucks", "title": "50% off handcrafted drinks after 3pm", "code": None, "discount": "50% off", "url": "https://starbucks.com", "expiry": "2026-03-14"},
        ],
    }

    results = []
    for store in stores:
        store_key = store.lower().strip()
        if store_key in mock_db:
            results.extend(mock_db[store_key])

    return results


# ── Run ────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
