"""
Agent Richy — Quick Test Script
================================
Test your Agent Richy assistant directly from the command line.

USAGE:
    python test_chat.py
"""

import os
import json
import time
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Load config
with open("./configs/assistant_config.json", "r") as f:
    config = json.load(f)

ASSISTANT_ID = config["assistant_id"]

TEST_QUESTIONS = [
    "I make $55,000 a year and have $8,000 in credit card debt at 22% APR. What should I do first?",
    "Explain the difference between a Roth IRA and Traditional IRA like I'm 25 years old.",
    "I want to teach my 8 year old about saving money. What should I do?",
    "How much do I need to save for retirement if I spend $4,000/month?",
    "Can you find me some coupons for Walmart and Target?",
]


def test_agent():
    print("=" * 60)
    print("🧪 Agent Richy — Test Suite")
    print("=" * 60)

    thread = client.beta.threads.create()
    print(f"\n📋 Thread ID: {thread.id}\n")

    for i, question in enumerate(TEST_QUESTIONS, 1):
        print(f"\n{'─' * 60}")
        print(f"❓ Test {i}: {question}")
        print(f"{'─' * 60}")

        # Send message
        client.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=question,
        )

        # Run assistant
        run = client.beta.threads.runs.create(
            thread_id=thread.id,
            assistant_id=ASSISTANT_ID,
        )

        # Wait for completion
        start = time.time()
        while run.status in ("queued", "in_progress"):
            time.sleep(0.5)
            run = client.beta.threads.runs.retrieve(
                thread_id=thread.id,
                run_id=run.id,
            )

        elapsed = time.time() - start

        if run.status == "completed":
            messages = client.beta.threads.messages.list(thread_id=thread.id, limit=1)
            response = messages.data[0].content[0].text.value

            # Truncate for display
            display = response[:500] + "..." if len(response) > 500 else response
            print(f"\n🤖 Richy ({elapsed:.1f}s):\n{display}")
        else:
            print(f"\n❌ Run failed: {run.status} - {run.last_error}")

    print(f"\n\n{'=' * 60}")
    print("✅ All tests complete!")
    print(f"{'=' * 60}")


def interactive_mode():
    """Chat with Richy interactively."""
    print("=" * 60)
    print("💬 Agent Richy — Interactive Chat")
    print("   Type 'quit' to exit")
    print("=" * 60)

    thread = client.beta.threads.create()

    while True:
        user_input = input("\n👤 You: ").strip()
        if user_input.lower() in ("quit", "exit", "q"):
            print("\n👋 Richy: See you next time! Keep building that wealth! 💰")
            break

        if not user_input:
            continue

        client.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=user_input,
        )

        run = client.beta.threads.runs.create(
            thread_id=thread.id,
            assistant_id=ASSISTANT_ID,
        )

        print("🤖 Richy is thinking...", end="", flush=True)

        while run.status in ("queued", "in_progress"):
            time.sleep(0.5)
            print(".", end="", flush=True)
            run = client.beta.threads.runs.retrieve(
                thread_id=thread.id,
                run_id=run.id,
            )

        if run.status == "completed":
            messages = client.beta.threads.messages.list(thread_id=thread.id, limit=1)
            response = messages.data[0].content[0].text.value
            print(f"\n\n🤖 Richy: {response}")
        else:
            print(f"\n\n❌ Error: {run.last_error}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
        interactive_mode()
    else:
        test_agent()
