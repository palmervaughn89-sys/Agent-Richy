# Agent Richy v2 — Bootstrap Package

## What's In This Package

Everything you need to get Agent Richy live as an AI-powered financial coach with coupon scalping.

```
agent-richy-bootstrap/
├── knowledge_base/                # Richy's brain (6 comprehensive docs)
│   ├── 01_budgeting.md           # Budgeting methods, subscription audits, bill strategies
│   ├── 02_debt_management.md     # Snowball/avalanche, consolidation, collections rights
│   ├── 03_investing.md           # Index funds, IRAs, 401k, crypto, tax-loss harvesting
│   ├── 04_savings_credit_taxes_insurance.md  # Emergency funds, credit scores, tax brackets
│   ├── 05_kids_education_life_events.md      # Teaching kids money, life event checklists
│   └── 06_calculators_and_reference.md       # All formulas + reference data tables
├── prompts/
│   └── system_prompt.md          # Richy's personality, behavior rules, response style
├── scripts/
│   ├── create_agent.py           # Creates the OpenAI Assistant + uploads knowledge base
│   ├── api_server.py             # FastAPI server (chat + coupons + avatar reactions)
│   └── test_chat.py              # Test suite + interactive chat mode
├── configs/                      # Generated after running create_agent.py
│   └── assistant_config.json     # Assistant ID, file IDs (auto-generated)
├── requirements.txt
├── .env.example
└── README.md
```

## Quick Start (5 Minutes)

### Step 1: Setup
```bash
cd agent-richy-bootstrap
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
```

### Step 2: Create the Agent
```bash
python scripts/create_agent.py
```
This uploads all 6 knowledge base docs to OpenAI, creates a vector store for RAG, and builds the assistant. You'll see the assistant ID printed — save it.

### Step 3: Test It
```bash
# Run automated tests
python scripts/test_chat.py

# Or chat interactively
python scripts/test_chat.py --interactive
```

### Step 4: Start the API Server
```bash
python scripts/api_server.py
# Or: uvicorn scripts.api_server:app --reload --port 8000
```

### Step 5: Test the API
```bash
# Chat with Richy
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "I have $5000 in credit card debt. What should I do?"}'

# Search coupons
curl -X POST http://localhost:8000/api/coupons/search \
  -H "Content-Type: application/json" \
  -d '{"stores": ["walmart", "target", "amazon"]}'

# Avatar reaction
curl -X POST "http://localhost:8000/api/keystroke?partial_text=crypto investing"
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | Send message to Richy, get response |
| `/api/chat/stream` | POST | Streaming response via SSE |
| `/api/coupons/search` | POST | Search coupons by store |
| `/api/coupons/daily` | POST | Get personalized daily deals |
| `/api/profile/shopping` | POST | Save shopping preferences |
| `/api/profile/shopping/{id}` | GET | Get shopping profile |
| `/api/savings/{id}` | GET | Get user's coupon savings total |
| `/api/savings/{id}/add` | POST | Track a redeemed coupon |
| `/api/keystroke` | POST | Get avatar expression for typed text |
| `/health` | GET | Health check |

## Connecting to Your Frontend

The API server is designed to plug directly into the React/Next.js frontend from the build spec. Point your frontend's API client at `http://localhost:8000` (or your deployed URL).

## Adding More Knowledge

To expand Richy's brain:
1. Add new `.md` files to `knowledge_base/`
2. Re-run `python scripts/create_agent.py`
3. The script will create a new assistant with all files

## Adding Real Coupon APIs

1. Sign up at one of these:
   - couponapi.org (free trial)
   - linkmydeals.com (free trial)
   - coupomated.com (affiliate-focused)
2. Add your API key to `.env`
3. The `api_server.py` already has the integration code — it'll switch from mock data to real data automatically

## Next Steps After Bootstrap

1. ✅ Run this package and verify Richy works
2. ✅ Sign up for a coupon API and enable real coupons
3. ✅ Feed this to Copilot along with the AGENT_RICHY_BUILD_SPEC.md to build the React frontend
4. ✅ Deploy: Backend on Railway/Fly.io, Frontend on Vercel
5. ✅ Add user auth (Clerk, NextAuth, or Supabase Auth)
6. ✅ Add database (Supabase or PlanetScale) for persistent profiles
7. ✅ Set up Stripe for $1 download + $2/month subscription
